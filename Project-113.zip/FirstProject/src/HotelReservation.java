public class HotelReservation {
	private int reservationID;
	private String checkInDate;
	private String checkOutDate;
	private double totalCost;
	private Room[] rooms;
	private int nbRooms;
	private int capacity;

	// Constructor
	public HotelReservation(int reservationID, String checkInDate, String checkOutDate,int capacity) {
		this.reservationID = reservationID;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		rooms = new Room[capacity];
		nbRooms = 0;
	}

	// Getters and setters
	public int getReservationID() {
		return reservationID;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}
	public double calculateTotalCost() {
		totalCost = 0;
		for(int i = 0; i < nbRooms; i++) {
			totalCost += rooms[i].calculatePrice();
		}
		return totalCost;
	}

	public boolean addRoom(Room room) {
		if (nbRooms < capacity) {
			rooms[nbRooms++] = room;
			if(room instanceof Suite)
				System.out.println("Suite room added to the reservation.");
			else
				System.out.println("Regular room added to the reservation.");
			
			return true;
		} else {
			System.out.println("Cannot add more rooms. Capacity has been reached.");
			return false;
		}
	}
	// Method to delete a room from the reservation
	public boolean removeRoom(int roomNumber) {
		Room roomToDelete = searchRoom(roomNumber);
		if (roomToDelete == null){	
			System.out.println("Room not found in the reservation.");
			return false;
		}
		for (int i = 0; i < nbRooms; i++) {
				if (rooms[i] == roomToDelete) {
					rooms[i] = rooms[nbRooms-1];
					rooms[--nbRooms] = null;
					System.out.println("Room deleted from the reservation.");
		 			return true;		
		      }	
		}
		return false;
	}
	// Method to find a room in the reservation
	public Room searchRoom(int roomNumber) {
		for (int i = 0; i < nbRooms; i++) {
			if (rooms[i].getRoomNumber() == roomNumber) {
				return rooms[i];
			}
		}
		return null;
	}

	public void display() {
		System.out.println(reservationID);
		System.out.println(checkInDate);
		System.out.println(checkOutDate);
		System.out.println(totalCost);
	}

}

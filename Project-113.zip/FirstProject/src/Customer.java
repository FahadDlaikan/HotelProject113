
public class Customer {
	    private int customerID;
	    private String name;
	    private String phoneNumber;
	    private HotelReservation reservation;
        private static int ReservationID = 101;
	    // Constructor
	    public Customer(int customerID, String name, String phoneNumber,int capacity,String checkInDate, String checkOutDate) {
	        this.customerID = customerID;
	        this.name = name;
	        this.phoneNumber = phoneNumber;
			reservation = new HotelReservation(ReservationID++,checkInDate,checkOutDate,capacity);
	    }
	    // Getters and setters
	    public int getCustomerID() {
	        return customerID;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getPhoneNumber() {
	        return phoneNumber;
	    }
	    public void Invoice() {
	    	System.out.println(customerID);
	    	System.out.println(name);
	    	System.out.println(phoneNumber);
	    	this.reservation.display();
	    }


	}



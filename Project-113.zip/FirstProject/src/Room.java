public abstract class Room {
	    protected int roomNumber;
	    protected String type;
	    protected boolean availability;
	    protected double nights;
	    private static final int NUMBER_OF_ROOMS = 150;

	    // Constructor
	    public Room(int roomNumber, String type,double nights) {
	        this.roomNumber = roomNumber;
	        this.type = type;
	        this.availability = true; // By default, room is available
	        this.nights = nights;
	    }
	    // Getters and setters
	    public int getRoomNumber() {
	        return roomNumber;
	    }

	    public boolean isAvailable() {
	        return availability;
	    }
	    public void setAvailability(boolean availability) {
	        this.availability = availability;
	    }
	    public abstract String getType();
	    
	    public abstract double calculatePrice();
	    
	    public abstract void displayInfo() ;
	    
	    // Abstract method to book the room
	    public abstract void bookRoom();

	    // Abstract method to check availability
	    public abstract void checkAvailability();
}
